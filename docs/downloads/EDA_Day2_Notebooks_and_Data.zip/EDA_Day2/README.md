# EDA Day 2 notebooks

Extract this whole folder and open it in Positron. Keep data/, support/, and notebooks/ together.

Run uv sync, then select the .venv Python interpreter as the notebook kernel.
The saved examples work with the base environment and local data.

For fresh Python UMAP/PHATE fits: uv sync --extra recompute.
Set RECOMPUTE = True in a completed notebook, or fill in the live scaffold's fitting calls.

Titanic: titanic_complete.ipynb and titanic_live_scaffold.ipynb.
Optional tornado exercise: tornado_practice.ipynb and tornado_complete.ipynb.

Saved UMAP uses official UMAP-js. Python recompute uses umap-learn and can produce a different layout.
Saved PCA/t-SNE use scikit-learn; PHATE uses its Python implementation.
Feature fingerprints and row IDs are validated before saved runs load.
